import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;


public class UnCompressionApp {
	private static String SAMPLEMARK = "@@";
	private static String NEXTLINE = "\r\n";
	private static String TAB = "\t";
	private static String COMMENTMARK = "##";

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the name of file to be uncompressed:");
		String compress_filename = sc.nextLine().trim();
		System.out.print("Please enter the name of generating uncompression file:");
		String new_filename = sc.nextLine().trim();
		System.out.println("Data is being processed,please wait...");
		try {
			UnCompressionApp r = new UnCompressionApp();
			r.restore(compress_filename, new_filename);
		} catch (Exception e) {
			System.out.println("Error,please check input and try again");
		}
		sc.close();
	}
	public void restore(String compress_filename, String new_filename)
			throws Exception {

		long start_time = System.currentTimeMillis();
		File file = FileUtil.file_exitst(new_filename);
		BufferedWriter output = new BufferedWriter(new FileWriter(file));
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream(compress_filename)));

		// process base data
		ArrayList<String[]> list = new ArrayList<String[]>();
		String baseline = br.readLine();
		while (baseline.startsWith(SAMPLEMARK)) {
			list.add(baseline.substring(SAMPLEMARK.length()).split(TAB));
			baseline = br.readLine();
		}
		String[][] sampleData = DataProcess.getBaseData(list);
		String currLine = baseline;
		while (currLine.startsWith(COMMENTMARK)) {
			output.write(currLine);
			output.write(NEXTLINE);
			currLine = br.readLine();
		}
		//Umcompression detail rows 
		while (currLine != null) {
			//Output the original record 
			//The user apply it by own requirements
			output.write(DataProcess.lineRecover3(currLine, sampleData));
			output.write(NEXTLINE);
			currLine = br.readLine();
		}
		output.flush();
		output.close();
		br.close();
		//System.out.println("total time:" + (System.currentTimeMillis() - start_time)/ 1000 + "s");
	}
}
